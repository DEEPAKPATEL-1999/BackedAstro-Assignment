# Backend-Assignment
1. Go step by step register => login => you will get json token. => use that token to perform CRUD operation for the todo list => Implemented Bonus freature to filter list we have to pass status completed or pending according to that they will filter and get list.
